
from flask import Flask, render_template, request
import joblib

app = Flask(__name__)

crop_model = joblib.load("models/crop_model.pkl")
fert_model = joblib.load("models/fertilizer_model.pkl")

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        data = [float(request.form[x]) for x in request.form]
        result = crop_model.predict([data])[0]
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
